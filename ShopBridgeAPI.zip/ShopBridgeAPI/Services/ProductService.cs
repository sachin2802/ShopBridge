﻿namespace ShopBridgeAPI
{
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using ShopBridgeAPI.Models;
    using ShopBridgeAPI.Services;
    using ShopBridgeAPI.ViewModels;

    public class ProductService : IProduct
    {
        private ProductContext _context;
        public ProductService(ProductContext context)
        {
            _context = context;
        }
        public List<Product> GetProductList()
        {
            List<Product> empList;
            try
            {
                empList = _context.Set<Product>().ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return empList;
        }
        public Product GetProductDetailsById(int empId)
        {
            Product emp;
            try
            {
                emp = _context.Find<Product>(empId);
            }
            catch (Exception)
            {
                throw;
            }
            return emp;
        }

        public ResponseModel SaveProduct(Product ProductModel)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                Product _temp = GetProductDetailsById(ProductModel.ProductId);
                if (_temp != null)
                {
                    _temp.Name = ProductModel.Name;
                    _temp.Discription = ProductModel.Discription;
                    _temp.Category = ProductModel.Category;
                    _temp.Price = ProductModel.Price;
                    _context.Update<Product>(_temp);
                    model.Messsage = "Product Update Successfully";
                }
                else
                {
                    _context.Add<Product>(ProductModel);
                    model.Messsage = "Product Inserted Successfully";
                }
                _context.SaveChanges();
                model.IsSuccess = true;
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.Messsage = "Error : " + ex.Message;
            }
            return model;
        }
        public ResponseModel UpdateProduct(Product ProductModel,int productid)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                Product _temp = GetProductDetailsById(productid);
                if (_temp != null)
                {
                    _temp.Name = ProductModel.Name;
                    _temp.Discription = ProductModel.Discription;
                    _temp.Category = ProductModel.Category;
                    _temp.Price = ProductModel.Price;
                    _context.Update<Product>(_temp);
                    _context.SaveChanges();
                    model.IsSuccess = true;
                    model.Messsage = "Product Update Successfully";
                }
                else
                {
                    model.IsSuccess = false;
                    model.Messsage = "Product Not Found";
                }
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.Messsage = "Error : " + ex.Message;
            }
            return model;

        }
        public ResponseModel DeleteProduct(int ProductId)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                Product _temp = GetProductDetailsById(ProductId);
                if (_temp != null)
                {
                    _context.Remove<Product>(_temp);
                    _context.SaveChanges();
                    model.IsSuccess = true;
                    model.Messsage = "Product Deleted Successfully";
                }
                else
                {
                    model.IsSuccess = false;
                    model.Messsage = "Product Not Found";
                }
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.Messsage = "Error : " + ex.Message;
            }
            return model;
        }
    }
}


        
