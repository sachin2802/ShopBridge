﻿using ShopBridgeAPI.Models;
using ShopBridgeAPI.ViewModels;
using System.Collections.Generic;

namespace ShopBridgeAPI.Services
{
    public interface IProduct
    {
        List<Product> GetProductList();
        Product GetProductDetailsById(int productId);
        ResponseModel SaveProduct(Product productModel);
        ResponseModel UpdateProduct(Product productModel,int productid);
        ResponseModel DeleteProduct(int productId);
    }
}