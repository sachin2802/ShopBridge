﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopBridgeAPI.Models;
using ShopBridgeAPI.Services;
using System;

namespace ShopBridgeAPI.Controller
{
    [Route("api/[controller]")]
    [ApiController]

    public class ProductController : ControllerBase
    {
        IProduct _productService;
        public ProductController(IProduct service)
        {
            _productService = service;
        }
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAllProduct()
        {
            try
            {
                var Product = _productService.GetProductList();
                if (Product == null) return NotFound();
                return Ok(Product);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpGet]
        [Route("[action]/id")]
        public IActionResult GetProductById(int id)
        {
            try
            {
                var Product = _productService.GetProductDetailsById(id);
                if (Product == null) return NotFound();
                return Ok(Product);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [Route("[action]")]
        public IActionResult SaveProduct(Product productModel)
        {
            try
            {
                var model = _productService.SaveProduct(productModel);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPut]
        [Route("[action]")]
        public IActionResult UpdateProduct(Product productModel,int id)
        {
            try
            {
                var model = _productService.UpdateProduct(productModel,id);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpDelete]
        [Route("[action]")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                var model = _productService.DeleteProduct(id);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
