﻿using System.ComponentModel.DataAnnotations;

namespace ShopBridgeAPI.Models
{
    public class Product
    {
        [Key]
        public int ProductId
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public string Discription
        {
            get;
            set;
        }
        public string Category
        {
            get;
            set;
        }
        public decimal Price
        {
            get;
            set;
        }
    }

}
