﻿using Microsoft.EntityFrameworkCore;
namespace ShopBridgeAPI.Models
{
    public class ProductContext: DbContext
    {
        public ProductContext(DbContextOptions options) : base(options) { }
        DbSet<Product> Product
        {
            get;
            set;
        }
    }
}
